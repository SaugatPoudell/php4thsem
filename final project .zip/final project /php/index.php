<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hamro Clinic</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    
</head>
<!-- <body> -->
<body background="https://images.pexels.com/photos/7578803/pexels-photo-7578803.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1">
   <div id="head"> <b>Hamro Clinic</b></div>
       
    
<!-- 
    <nav> -->
    <div class="btn-group">
  <a href="index.php" class="btn btn-danger" aria-current="page">Home</a>
  <a href="Appoint.php" class="btn btn-primary">Appointment</a>
  <a href="adminlogin.php" class="btn btn-primary">Admin</a>
  <a href="aboutus.php" class="btn btn-primary">About Us</a>
</div>
<div class="container pt-3">
    <div class="row">
      <div class="col">
        <div class="bg-light">
        <img src="1234.jpg">
        <p class="px-2 py-3">
            Hamro Clinic Provides the world class services realted to ENT(Eyes,Nose and Throat) realated disesases with world class service and the people who work with the hamro clinic are in already in the top of the world and they are the best doctor related to the field of the science and techology and they are rallly knowing that the Hamro Clinic does the best job in the world hence they are in this part of the system
    </p>
</div>
      </div>
      <div class="col">
        <div class="bg-light">
        <img src="123.jpg">
        <p class="px-2 py-3">
            Hamro Clinic Provides the world class services realted to ENT(Eyes,Nose and Throat) realated disesases with world class service and the people who work with the hamro clinic are in already in the top of the world and they are the best doctor related to the field of the science and techology and they are rallly knowing that the Hamro Clinic does the best job in the world hence they are in this part of the system
    </p>
</div>
      </div>
    </div>

        <!-- <a href="index.php">Home</a>
        <a href="Appoint.php">Appointment</a>
        <a href="adminlogin.php">Admin</a> -->


    <!-- <div id="first">
        <p>Hamro Clinic, one of the pioneer of providing online booking system is simply the best clinic which provides e-Booking system to the patients reducing the time of waitig for the people while joining the checkup period.</p>
    </div> -->
    </div>
    <div id="second">
    <a href="Appoint.php">
      <button class="btn btn-primary w-auto px-5">Book Appointment</button>
    </a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    
</script>
</body>
</html>
//<!-- <?php
include("connect.php");
// $host="localhost";
// $user="root";
// $password="";
// $db="demo";
// $conn=mysqli_connect($host,$user,$password);
// if($conn)
// {
    
// }
// else
// {
//     die("Error". mysqli_connect_error());
// }
// ?> -->