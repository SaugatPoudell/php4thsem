<?php 
?>
<html>
    <body>
  <center><h2>Welcome to ADMIN PANEL</h2></center>
  <nav>
      <a href="http://localhost/php/adminpanel.php">Home</a>
      <br>
      <a href="index.php">Home Page</a>
      <br>
      <a href="booked.php">Booked Appointment</a>
      <br>

      <form action=logout.php method=post>
      <input type=submit name=submit value=logout>
</form>
</nav>
</body>
</html>
